#!/usr/bin/env python3
"""Construct a PCC-native, full-file overlay against the exact certified Git baseline.

The source is read from the user's local GREEN tree; it is never taken from an old
ChatGPT snapshot. No tracked source is changed by this generator.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

BASE_COMMIT = '31442f2502a89f81086aacdd136a586753bcc2d7'
BASE_DOCK_BLOB = '197270d06610f9f69cc65d82c83ca9d9c8527304'
DOCK_FILE = 'engine/src/ui/SubspaceUiFramework.cpp'
PATCH_NAME = 'Subspace_PASS1507_Dock_ActiveTab_Overlap_Fix.patch'

# This exact control flow has been checked against the certified 31442f2 source.
LAYOUT_ANCHOR = '''    for(const auto& panelId:n->tabs){
        const auto* p=SubspaceDockSystem::FindPanel(w,panelId);
'''
LAYOUT_REPAIR = '''    // PASS1507: a leaf is a tab stack, not a pile of simultaneous panels.
    // A closed/auto-hidden active tab yields to the first available sibling.
    auto usable=[&](const std::string& id){
        const auto* panel=SubspaceDockSystem::FindPanel(w,id);
        return panel&&panel->visible&&(!panel->autoHide||panel->pinned||panel->hoverReveal);
    };
    std::string active=Contains(n->tabs,n->activeTabId)&&usable(n->activeTabId)
        ?n->activeTabId:std::string{};
    if(active.empty())for(const auto& candidate:n->tabs){
        if(usable(candidate)){active=candidate;break;}
    }
    for(const auto& panelId:n->tabs){
        if(panelId!=active)continue;
        const auto* p=SubspaceDockSystem::FindPanel(w,panelId);
'''
CLOSE_ANCHOR = '''bool SubspaceDockSystem::ClosePanel(SubspaceDockWorkspace& w,const std::string& id){auto* p=FindPanel(w,id);if(!p||!p->closable)return false;p->visible=false;return true;}'''
CLOSE_REPAIR = '''bool SubspaceDockSystem::ClosePanel(SubspaceDockWorkspace& w,const std::string& id){
    auto* p=FindPanel(w,id);
    if(!p||!p->closable)return false;
    p->visible=false;
    // Do not leave the dock stack pointing at a hidden tab after a close.
    for(auto& node:w.nodes){
        if(node.split||node.activeTabId!=id)continue;
        node.activeTabId.clear();
        for(const auto& candidate:node.tabs){
            const auto* next=FindPanel(w,candidate);
            if(next&&next->visible&&(!next->autoHide||next->pinned||next->hoverReveal)){
                node.activeTabId=candidate;
                break;
            }
        }
    }
    return true;
}'''

TEST_CPP = r'''// PASS1507: exercise the actual dock runtime, not source-token strings.
#include "ui/SubspaceUiFramework.h"
#include <cstdlib>
#include <iostream>
#include <string>

using namespace subspace;
static void Check(bool ok,const char* what){
    if(!ok){std::cerr<<"[FAIL] "<<what<<'\n';std::exit(1);}
}
static bool Has(const std::vector<SubspaceDockLayout>& layouts,const std::string& id,bool floating=false){
    for(const auto& layout:layouts)
        if(layout.panelId==id&&layout.visible&&layout.floating==floating)return true;
    return false;
}
int main(){
    auto workspace=SubspaceDockSystem::CreateMinimalWorkspace("pass1507");
    SubspaceDockPanel a;
    a.id="properties";a.title="Properties";a.defaultLeafId="right";
    SubspaceDockPanel b=a;
    b.id="modeling";b.title="Modeling";
    Check(SubspaceDockSystem::RegisterPanel(workspace,a),"register properties");
    Check(SubspaceDockSystem::RegisterPanel(workspace,b),"register modeling");
    auto layouts=SubspaceDockSystem::Materialize(workspace,1280,768);
    Check(Has(layouts,"properties")&&!Has(layouts,"modeling"),"only active tab is materialized");
    Check(SubspaceDockSystem::ActivatePanel(workspace,"modeling"),"activate modeling");
    layouts=SubspaceDockSystem::Materialize(workspace,1280,768);
    Check(Has(layouts,"modeling")&&!Has(layouts,"properties"),"activation swaps dock content");
    Check(SubspaceDockSystem::ClosePanel(workspace,"modeling"),"close modeling");
    layouts=SubspaceDockSystem::Materialize(workspace,1280,768);
    Check(Has(layouts,"properties")&&!Has(layouts,"modeling"),"close restores visible sibling");
    Check(SubspaceDockSystem::OpenPanel(workspace,"modeling"),"reopen modeling");
    layouts=SubspaceDockSystem::Materialize(workspace,1280,768);
    Check(Has(layouts,"modeling")&&!Has(layouts,"properties"),"reopen activates modeling");
    Check(SubspaceDockSystem::FloatPanel(workspace,"modeling",{100,120,350,300}),"float modeling");
    layouts=SubspaceDockSystem::Materialize(workspace,1280,768);
    Check(Has(layouts,"properties")&&Has(layouts,"modeling",true),"floating panel does not obscure dock tab state");
    Check(SubspaceDockSystem::DockPanel(workspace,"modeling","right"),"redock modeling");
    layouts=SubspaceDockSystem::Materialize(workspace,1280,768);
    Check(Has(layouts,"modeling")&&!Has(layouts,"properties"),"redock activates only target tab");
    const auto serialized=SubspaceDockSystem::Serialize(workspace);
    SubspaceDockWorkspace restored;
    std::string error;
    Check(SubspaceDockSystem::Deserialize(serialized,restored,&error),"restore serialized dock layout");
    layouts=SubspaceDockSystem::Materialize(restored,1280,768);
    Check(Has(layouts,"modeling")&&!Has(layouts,"properties"),"active tab survives layout restart");
    std::cout<<"PASS1507 native active-tab/dock/float/reopen/persistence tests PASS\n";
}
'''
TEST_CMAKE = '''cmake_minimum_required(VERSION 3.20)
project(SubspacePass1507DockRegression LANGUAGES CXX)
get_filename_component(SUBSPACE_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
add_executable(pass1507_dock_regression
    "${SUBSPACE_ROOT}/engine/src/ui/SubspaceUiFramework.cpp"
    "${CMAKE_CURRENT_LIST_DIR}/pass1507_dock_active_tab_tests.cpp")
target_include_directories(pass1507_dock_regression PRIVATE "${SUBSPACE_ROOT}/engine/include")
target_compile_features(pass1507_dock_regression PRIVATE cxx_std_17)
enable_testing()
add_test(NAME pass1507_dock_regression COMMAND pass1507_dock_regression)
'''
STATIC_GATE = '''cmake_minimum_required(VERSION 3.20)
# PASS1507 source guard; the separate native test executes real dock behavior.
get_filename_component(ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
file(READ "${ROOT}/engine/src/ui/SubspaceUiFramework.cpp" SOURCE)
foreach(REQUIRED IN ITEMS
  "PASS1507: a leaf is a tab stack"
  "if(panelId!=active)continue;"
  "node.activeTabId.clear();"
  "node.activeTabId=candidate;")
  string(FIND "${SOURCE}" "${REQUIRED}" POS)
  if(POS EQUAL -1)
    message(FATAL_ERROR "PASS1507 missing active-tab repair: ${REQUIRED}")
  endif()
endforeach()
if(NOT EXISTS "${ROOT}/tools/control/pass1507-dock-test/pass1507_dock_active_tab_tests.cpp")
  message(FATAL_ERROR "PASS1507 native test missing")
endif()
message(STATUS "PASS1507 dock active-tab source gate PASS (native test runs separately)")
'''
README = '''# PASS1507 — Dock active-tab overlap correction

Baseline: `31442f2502a89f81086aacdd136a586753bcc2d7`, certified by Windows PCC.

This corrects an actual behavior defect in the existing shared docking implementation:
`LayoutNode` previously emitted a panel layout for *every* visible tab in one leaf,
so opening a second right-hand editor could place it over Properties. Only the active
eligible tab now materializes. Closing the active tab selects a visible sibling.
Floating, redocking and layout persistence are covered by a native regression test.

This does **not** implement dragging arbitrary panels, separate OS windows, tooltip
animations or the rest of PASS1507–1515. Those remain unaccepted workflows.

After PCC applies the generated .patch, run your normal Full Gate, then run the
focused native test (if your CMake generator is configured):

    cmake -S tools/control/pass1507-dock-test -B engine/build/pass1507-dock-test
    cmake --build engine/build/pass1507-dock-test --config Debug
    ctest --test-dir engine/build/pass1507-dock-test -C Debug --output-on-failure

Open Shipyard and switch right-hand panel tabs while observing overlapping text.
Only the selected tab should occupy the right-hand leaf; after closing it, the
previous available tab should appear. Treat Windows runtime acceptance separately.
'''


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def patch_source(text: str) -> str:
    if text.count(LAYOUT_ANCHOR) != 1:
        raise ValueError('LayoutNode anchor absent or ambiguous; refusing to overwrite newer source')
    if text.count(CLOSE_ANCHOR) != 1:
        raise ValueError('ClosePanel anchor absent or ambiguous; refusing to overwrite newer source')
    return text.replace(LAYOUT_ANCHOR, LAYOUT_REPAIR, 1).replace(CLOSE_ANCHOR, CLOSE_REPAIR, 1)


def git(root: Path, *args: str) -> str:
    result = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True, check=True)
    return result.stdout.strip()


def build(root: Path) -> Path:
    root = root.resolve(strict=True)
    if not (root / '.git').exists():
        raise ValueError('Target must be the actual certified Git repository root')
    if Path(git(root, 'rev-parse', '--show-toplevel')).resolve() != root:
        raise ValueError('Provided folder is not the Git root')
    head = git(root, 'rev-parse', 'HEAD')
    if head.lower() != BASE_COMMIT:
        raise ValueError(f'Baseline mismatch: expected {BASE_COMMIT}, got {head}. No files changed.')
    if git(root, 'status', '--porcelain', '--untracked-files=no'):
        raise ValueError('Tracked working tree is not clean. No files changed.')
    pending = sorted(x.name for x in root.glob('*.patch') if x.is_file())
    if pending:
        raise ValueError('Existing pending root patches must be resolved first: ' + ', '.join(pending))
    source = root / DOCK_FILE
    if source.is_symlink() or not source.is_file():
        raise ValueError('Missing or symlinked dock implementation: ' + DOCK_FILE)
    blob = git(root, 'hash-object', '--', DOCK_FILE)
    if blob.lower() != BASE_DOCK_BLOB:
        raise ValueError(f'Dock source blob differs from certified baseline: {blob}. No files changed.')
    original = source.read_bytes()
    if b'\x00' in original:
        raise ValueError('Dock source appears binary')
    try:
        raw = original.decode('utf-8')
    except UnicodeDecodeError as exc:
        raise ValueError('Dock source is not UTF-8') from exc
    # Keep the existing newline style and exact original byte encoding.
    newline = '\r\n' if b'\r\n' in original else '\n'
    normalized = raw.replace('\r\n', '\n')
    rewritten = patch_source(normalized).replace('\n', newline).encode('utf-8')
    if rewritten == original:
        raise ValueError('Dock source already matches intended repair')
    payload = {
        DOCK_FILE: rewritten,
        'tools/control/pass1507-dock-test/CMakeLists.txt': TEST_CMAKE.encode('utf-8'),
        'tools/control/pass1507-dock-test/pass1507_dock_active_tab_tests.cpp': TEST_CPP.encode('utf-8'),
        'tools/control/static-gates/pass1507_dock_active_tab_overlap.cmake': STATIC_GATE.encode('utf-8'),
        'docs/shipyard/PASS1507_DOCK_ACTIVE_TAB_REPAIR.md': README.encode('utf-8'),
    }
    for path in payload:
        if path != DOCK_FILE and (root / path).exists():
            raise ValueError(f'New payload path already exists: {path}. No files changed.')
    manifest = {
        'schemaVersion': 1,
        'schema': 'forge.patch.v1',
        'patchId': 'SUBSPACE-PASS1507-DOCK-ACTIVE-TAB-OVERLAP',
        'projectId': 'codename-subspace',
        'basePass': 1506,
        'targetPass': 1507,
        'baseline': {'gitCommit': BASE_COMMIT},
        'sourcePreflight': {'path': DOCK_FILE, 'gitBlobSha': blob, 'sha256': sha256(original)},
        'files': [{'path': name, 'sha256': sha256(data), 'bytes': len(data)} for name, data in sorted(payload.items())],
        'remove': []
    }
    dest = root / PATCH_NAME
    if dest.exists():
        raise ValueError(f'Output already exists; refusing overwrite: {dest}')
    # Zip only after ALL preflight and transformations completed successfully.
    with zipfile.ZipFile(dest, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('PATCH_MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
        for name, data in sorted(payload.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(dest) as archive:
        for entry in manifest['files']:
            actual = archive.read(entry['path'])
            if len(actual) != entry['bytes'] or sha256(actual) != entry['sha256']:
                dest.unlink(missing_ok=True)
                raise RuntimeError('Archive payload verification failed')
    print('PCC PATCH GENERATED:', dest)
    print('Baseline:', BASE_COMMIT)
    print('Changed tracked files: 1 (dock implementation); new files: 4')
    print('Patch SHA-256:', sha256(dest.read_bytes()))
    print('Tracked repository sources were NOT modified; relaunch PCC to approve/apply.')
    return dest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path, help='Path to the certified CodenameSubspaceNullharbor Git root')
    args = parser.parse_args()
    try:
        build(args.root)
    except (ValueError, OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('PASS1507 PRECONDITION FAIL:', exc, file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
