@echo off
setlocal
if "%~1"=="" (
 echo Usage: Drag your CodenameSubspaceNullharbor folder onto this .cmd file,
 echo or run: Generate_PASS1507_DockFix.cmd "C:\path\to\CodenameSubspaceNullharbor"
 pause
 exit /b 2
)
where py >nul 2>nul
if not errorlevel 1 (
 py -3 "%~dp0Generate_PASS1507_DockFix.py" "%~1"
) else (
 python "%~dp0Generate_PASS1507_DockFix.py" "%~1"
)
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
 echo No source or patch was modified by a failed precondition.
) else (
 echo Relaunch SubspaceTools.cmd inside your project and approve the new root patch.
)
pause
exit /b %RESULT%
