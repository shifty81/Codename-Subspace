# Subspace G4 R2 — invisible hull hotfix / guarded patch builder

**This ZIP is not a root-drop patch. Do not put it unextracted in your Subspace repository.** Extract it *outside* the repository (for example, on Desktop). It does not overwrite Subspace source: the script reads your committed files, verifies the exact `cf5107e4b36881ebfbcb46325a31558e84979597` Git baseline and four source blob hashes, rejects dirty target files or mismatches, and creates a canonical PCC `.patch` outside the repository.

From PowerShell 7 (or Windows PowerShell 5.1), in the extracted kit folder:

```powershell
.\Prepare-HullVisibility-R2.ps1 -Repository 'C:\Users\Shifty\Desktop\CodenameSubspaceNullharbor'
```

Then copy **only the generated** `Subspace_G4_R2_Hull_Visibility_cf5107e.patch` into the repository root. Approve it using your existing PCC, run Full Quality Gate and do the manual checks in `TEST_PLAN.md`. Commit/push only if gate and visual checks pass.

If baseline or source hash checks fail, stop. Do not reset, cherry-pick or bypass the guard. A newer commit needs a newly matched package. Do not reapply prior G4/G5 or R1 patches. This R2 package addresses *hull visibility*, not the remaining camera shortcuts or Fleet Command features.

The PowerShell builder is generated here but cannot be executed or Windows-certified in this Linux environment. The underlying view-policy C++ smoke test has been run here; your project-owned Windows gate is still authoritative.
