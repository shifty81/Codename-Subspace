# Produces a PCC .patch from the user's exact certified commit. Never edits repository files.
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Repository,
    [string]$Output = ''
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$expectedHead = 'cf5107e4b36881ebfbcb46325a31558e84979597'
$repo = [IO.Path]::GetFullPath($Repository)
if (-not (Test-Path -LiteralPath (Join-Path $repo 'project.control.json') -PathType Leaf)) { throw 'Not a Subspace project root.' }
$gitRoot = @(& git -C $repo rev-parse --show-toplevel 2>$null)
if ($LASTEXITCODE -ne 0 -or $gitRoot.Count -ne 1) { throw 'Cannot establish Git repository root.' }
if (-not ([IO.Path]::GetFullPath([string]$gitRoot[0]).TrimEnd([char[]]@([char]92,[char]47)).Equals($repo.TrimEnd([char[]]@([char]92,[char]47)),[StringComparison]::OrdinalIgnoreCase))) {
    throw 'Repository path must be the actual Git root.'
}
$head = @(& git -C $repo rev-parse HEAD 2>$null)
if ($LASTEXITCODE -ne 0 -or $head.Count -ne 1 -or ([string]$head[0]).Trim() -ne $expectedHead) {
    throw "BASELINE_CONFLICT: This kit requires $expectedHead. Do not reset or overwrite your newer source."
}
$sourcePath = 'engine/src/ship_editor/ShipyardProfessionalVisibleCutover.cpp'
$builderPath = 'engine/src/ship_editor/ShipyardBuilderSystem.cpp'
$headerPath = 'engine/include/ship_editor/ShipyardStudioViewMode.h'
$testPath = 'engine/tests/shipyard_studio_g3_workflow_tests.cpp'
$docPath = 'docs/shipyard/SUBSPACE_G4_HULL_VISIBILITY_R2.md'
$expectedBlobs = [ordered]@{
    'engine/src/ship_editor/ShipyardProfessionalVisibleCutover.cpp' = '6505191a5ba5feb381454b73abd6d8ddb7ec56c7'
    'engine/src/ship_editor/ShipyardBuilderSystem.cpp' = 'b6baa09d704d1ea15e34e75d5c468c91971ecc6e'
    'engine/include/ship_editor/ShipyardStudioViewMode.h' = 'c76740038e889a95636681729fe299f04ee6c134'
    'engine/tests/shipyard_studio_g3_workflow_tests.cpp' = '786e0531cce80deb3043dc57c9a8b81038ee1255'
}
$paths = @($expectedBlobs.Keys) + @($docPath)
$dirty = @(& git -C $repo status --porcelain -- $paths 2>$null)
if ($LASTEXITCODE -ne 0) { throw 'Cannot inspect working-tree status for patch paths.' }
if ($dirty.Count -gt 0) { throw ('DIRTY_SOURCE_CONFLICT: commit and certify or preserve local edits first: ' + ($dirty -join ' | ')) }
foreach ($path in $expectedBlobs.Keys) {
    $full = Join-Path $repo $path
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Missing expected source: $path" }
    $blob = @(& git -C $repo rev-parse ("HEAD:"+$path) 2>$null)
    if ($LASTEXITCODE -ne 0 -or $blob.Count -ne 1 -or ([string]$blob[0]).Trim() -ne [string]$expectedBlobs[$path]) {
        throw "SOURCE_CONFLICT: $path differs from the independently verified cf5107e file. No package produced."
    }
}
if (Test-Path -LiteralPath (Join-Path $repo $docPath)) { throw 'Documentation path already exists; no overwrite allowed.' }
$utf8 = [System.Text.UTF8Encoding]::new($false,$true)
function Replace-Once([string]$text,[string]$before,[string]$after,[string]$label) {
    $first = $text.IndexOf($before,[StringComparison]::Ordinal)
    if ($first -lt 0 -or $text.IndexOf($before,$first+$before.Length,[StringComparison]::Ordinal) -ge 0) {
        throw "SOURCE_ANCHOR_CONFLICT: expected one unique $label location. No package produced."
    }
    return $text.Substring(0,$first)+$after+$text.Substring($first+$before.Length)
}
function Read-Source([string]$rel) {
    $raw = [IO.File]::ReadAllText((Join-Path $repo $rel),$utf8)
    # Edits are normalized and original CRLF restored on output.
    return $raw.Replace("`r`n","`n")
}
$viewHeader = Read-Source $headerPath
$headerBefore = '    static constexpr const char* Name(ShipyardStudioViewMode m){'
$headerAfter = @'
    // Interior-only is an inspection view; exterior workspaces must show hulls.
    static constexpr ShipyardStudioViewMode ForWorkspace(ShipyardStudioViewMode current,bool interior){
        if(interior)return current==ShipyardStudioViewMode::Exterior?ShipyardStudioViewMode::InteriorOnly:current;
        return current==ShipyardStudioViewMode::InteriorOnly?ShipyardStudioViewMode::Exterior:current;
    }
    static constexpr const char* Name(ShipyardStudioViewMode m){
'@
$viewHeader = Replace-Once $viewHeader $headerBefore $headerAfter.TrimEnd("`r","`n") 'studio view policy'

$source = Read-Source $sourcePath
$cycleBefore = @'
        const auto next=order[index];if(next==ShipyardWorkspaceMode::Test){model_.workspaceMode=ShipyardWorkspaceMode::Test;model_.testWorkspaceActive=true;model_.developerWorkspacesVisible=false;model_.status="Test workspace";return true;}
        model_.testWorkspaceActive=false;return LegacyActivate(WorkspaceCommand(next),0);}
'@
$cycleAfter = @'
        const auto next=order[index];
        if(next==ShipyardWorkspaceMode::Test){
            model_.studioViewMode=ShipyardStudioViewSystem::ForWorkspace(model_.studioViewMode,false);
            model_.workspaceMode=ShipyardWorkspaceMode::Test;model_.testWorkspaceActive=true;
            model_.developerWorkspacesVisible=false;model_.status="Test workspace";return true;
        }
        model_.testWorkspaceActive=false;
        const bool changed=LegacyActivate(WorkspaceCommand(next),0);
        if(changed)model_.studioViewMode=ShipyardStudioViewSystem::ForWorkspace(model_.studioViewMode,next==ShipyardWorkspaceMode::Interior);
        return changed;}
'@
$source = Replace-Once $source $cycleBefore.TrimEnd("`r","`n") $cycleAfter.TrimEnd("`r","`n") 'keyboard workspace transition'
$clickedBefore = @'
    const bool result=LegacyActivate(command,value);
    if(result&&command==ShipyardBuilderCommand::WorkspaceInterior&&
       model_.studioViewMode==ShipyardStudioViewMode::Exterior)
        model_.studioViewMode=ShipyardStudioViewMode::InteriorOnly;
'@
$clickedAfter = @'
    const auto priorWorkspace=model_.workspaceMode;
    const bool result=LegacyActivate(command,value);
    if(result&&(model_.workspaceMode!=priorWorkspace||
                command==ShipyardBuilderCommand::WorkspaceInterior||command==ShipyardBuilderCommand::WorkspaceBuild))
        model_.studioViewMode=ShipyardStudioViewSystem::ForWorkspace(
            model_.studioViewMode,model_.workspaceMode==ShipyardWorkspaceMode::Interior);
'@
$source = Replace-Once $source $clickedBefore.TrimEnd("`r","`n") $clickedAfter.TrimEnd("`r","`n") 'clicked workspace transition'

$builder = Read-Source $builderPath
$dragBefore = @'
    const auto filtered=FilteredCatalogIndices();if(filteredIndex<0||static_cast<std::size_t>(filteredIndex)>=filtered.size())return false;model_.selectedFilteredModule=static_cast<std::size_t>(filteredIndex);const auto& child=model_.catalog[filtered[model_.selectedFilteredModule]];model_.dragPreview=ShipyardDragDropSystem::Begin(child,model_.catalog,model_.recipe,model_.targetModuleSize);model_.status=model_.dragPreview.status;return model_.dragPreview.active;
'@
$dragAfter = @'
    const auto filtered=FilteredCatalogIndices();if(filteredIndex<0||static_cast<std::size_t>(filteredIndex)>=filtered.size())return false;model_.selectedFilteredModule=static_cast<std::size_t>(filteredIndex);const auto& child=model_.catalog[filtered[model_.selectedFilteredModule]];model_.dragPreview=ShipyardDragDropSystem::Begin(child,model_.catalog,model_.recipe,model_.targetModuleSize);
    // Reveal an authored hull immediately, including the first empty-document ghost.
    if(model_.dragPreview.active&&model_.studioViewMode==ShipyardStudioViewMode::InteriorOnly)
        model_.studioViewMode=ShipyardStudioViewMode::Exterior;
    model_.status=model_.dragPreview.status;return model_.dragPreview.active;
'@
$builder = Replace-Once $builder $dragBefore.TrimEnd("`r","`n") $dragAfter.TrimEnd("`r","`n") 'catalog drag reveal'
$addBefore = '        case ShipyardBuilderCommand::AddModule:changed=model_.dragPreview.staged?CommitCatalogDrag():AddSelectedModule();break;'
$addAfter = @'
        case ShipyardBuilderCommand::AddModule:changed=model_.dragPreview.staged?CommitCatalogDrag():AddSelectedModule();
            if(changed&&model_.studioViewMode==ShipyardStudioViewMode::InteriorOnly)model_.studioViewMode=ShipyardStudioViewMode::Exterior;
            break;
'@
$builder = Replace-Once $builder $addBefore $addAfter.TrimEnd("`r","`n") 'direct module placement reveal'
$commitBefore = @'
    model_.selectedPlacedModule=childIndex;model_.dragPreview={};model_.dirty=true;SyncCatalogSelectionToPlaced();RefreshForwardAuthority();InvalidateRecipeMetadata();model_.validation=Validate();if(pendingDragHistory_){PushAuthoringSnapshot(*pendingDragHistory_);pendingDragHistory_.reset();}return true;
'@
$commitAfter = @'
    model_.selectedPlacedModule=childIndex;model_.dragPreview={};model_.dirty=true;SyncCatalogSelectionToPlaced();RefreshForwardAuthority();InvalidateRecipeMetadata();model_.validation=Validate();
    if(model_.studioViewMode==ShipyardStudioViewMode::InteriorOnly)model_.studioViewMode=ShipyardStudioViewMode::Exterior;
    if(pendingDragHistory_){PushAuthoringSnapshot(*pendingDragHistory_);pendingDragHistory_.reset();}return true;
'@
$builder = Replace-Once $builder $commitBefore.TrimEnd("`r","`n") $commitAfter.TrimEnd("`r","`n") 'commit placement reveal'

$test = Read-Source $testPath
$testBefore = '    auto mode=ShipyardStudioViewMode::Exterior;'
$testAfter = @'
    auto mode=ShipyardStudioViewMode::Exterior;
    Check(ShipyardStudioViewSystem::ForWorkspace(ShipyardStudioViewMode::Exterior,true)==ShipyardStudioViewMode::InteriorOnly,"entering interior shows generated interior");
    Check(ShipyardStudioViewSystem::ForWorkspace(ShipyardStudioViewMode::InteriorOnly,false)==ShipyardStudioViewMode::Exterior,"returning to build reveals placed hulls");
    Check(ShipyardStudioViewSystem::ForWorkspace(ShipyardStudioViewMode::Cutaway,false)==ShipyardStudioViewMode::Cutaway,"explicit cutaway survives workspace change");
    Check(ShipyardStudioViewSystem::ForWorkspace(ShipyardStudioViewMode::XRay,false)==ShipyardStudioViewMode::XRay,"explicit X-ray survives workspace change");
    Check(ShipyardStudioViewSystem::ForWorkspace(ShipyardStudioViewMode::Exterior,false)==ShipyardStudioViewMode::Exterior,"build keeps exterior visible");
'@
$test = Replace-Once $test $testBefore $testAfter.TrimEnd("`r","`n") 'studio G3 regression assertions'

# Verify all mutations before writing the transport; source files are never edited.
if (-not ($viewHeader.Contains('ForWorkspace(') -and $source.Contains('const auto priorWorkspace=') -and
          $source.Contains('const bool changed=LegacyActivate(WorkspaceCommand(next),0)') -and
          $builder.Contains('Reveal an authored hull immediately') -and $test.Contains('returning to build reveals placed hulls'))) {
    throw 'Internal post-transform verification failed.'
}
$doc = @'
# G4 R2 — Invisible hull after Interior → Build

Source basis: cf5107e4b36881ebfbcb46325a31558e84979597. Do not reapply earlier G4/G5 or R1 patches.

Fix: entering Interior from Exterior defaults to Interior-only; returning to Build or another exterior workspace automatically restores Exterior if Interior-only was active. Both clicked workspaces and keyboard workspace cycling are covered. Starting a catalog drag and committing a hull also reveal Exterior if the user explicitly selected Interior-only while assembling. Cutaway and X-Ray views are preserved across workspace changes.

No recipe, Outliner, mesh, renderer, PCC, fleet command or cockpit source is replaced. First-module drag ghost continues to be rendered from existing renderer path.

Acceptance: enter Interior, switch Build, drag a hull from empty recipe, ensure translucent ghost appears, stage/PLACE, verify rendered geometry and Outliner agree, select and Frame Selected. Repeat through workspace keyboard cycling; verify Cutaway/X-Ray not overwritten. If EXTERIOR remains blank, check logs for SHIPYARD_RUNTIME_NOT_READY or could-not-load certified module warnings, plus verify active moduleId is present in certified mesh catalog. Do not fabricate fallback hull geometry.

Source and header assertions are not Windows render acceptance. Run PCC Full Gate, perform hands-on 1280x768 and 1920x1080 tests, then commit/push only if green and visible.
'@
$stage = Join-Path ([IO.Path]::GetTempPath()) ('subspace-visibility-r2-'+[Guid]::NewGuid().ToString('N'))
try {
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    $contents = [ordered]@{
        'engine/src/ship_editor/ShipyardProfessionalVisibleCutover.cpp' = $source
        'engine/src/ship_editor/ShipyardBuilderSystem.cpp' = $builder
        'engine/include/ship_editor/ShipyardStudioViewMode.h' = $viewHeader
        'engine/tests/shipyard_studio_g3_workflow_tests.cpp' = $test
        'docs/shipyard/SUBSPACE_G4_HULL_VISIBILITY_R2.md' = $doc
    }
    $manifestFiles = @()
    foreach ($path in $contents.Keys) {
        $outPath = Join-Path $stage $path
        New-Item -ItemType Directory -Path (Split-Path -Parent $outPath) -Force | Out-Null
        $originalPath = Join-Path $repo $path
        $newline = if ((Test-Path -LiteralPath $originalPath) -and [IO.File]::ReadAllText($originalPath,$utf8).Contains("`r`n")) { "`r`n" } else { "`n" }
        $text = ([string]$contents[$path]).Replace("`r`n","`n").Replace("`n",$newline)
        [IO.File]::WriteAllText($outPath,$text,$utf8)
        $bytes = [IO.File]::ReadAllBytes($outPath)
        $sha = (Get-FileHash -LiteralPath $outPath -Algorithm SHA256).Hash.ToLowerInvariant()
        $manifestFiles += [ordered]@{path=$path;sha256=$sha;bytes=$bytes.Length}
    }
    $manifest = [ordered]@{
        schemaVersion=1;schema='forge.patch.v1';patchId='subspace-g4-hull-visibility-r2-cf5107e';
        target=[ordered]@{projectId='codename-subspace'};
        baseline=[ordered]@{gitCommit=$expectedHead};
        createdUtc=(Get-Date).ToUniversalTime().ToString('o');files=$manifestFiles;remove=@()
    }
    [IO.File]::WriteAllText((Join-Path $stage 'PATCH_MANIFEST.json'),($manifest|ConvertTo-Json -Depth 9),$utf8)
    if (-not $Output) { $Output = Join-Path (Split-Path -Parent $repo) 'Subspace_G4_R2_Hull_Visibility_cf5107e.patch' }
    $out = [IO.Path]::GetFullPath($Output)
    $prefix=$repo.TrimEnd([char[]]@([char]92,[char]47))+[IO.Path]::DirectorySeparatorChar
    if ($out.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Output .patch must first be generated outside repository.' }
    if ([IO.Path]::GetExtension($out) -ine '.patch') { throw 'Output must end .patch.' }
    if (Test-Path -LiteralPath $out) { throw 'Refusing to overwrite existing patch.' }
    New-Item -ItemType Directory -Path (Split-Path -Parent $out) -Force | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($stage,$out,[IO.Compression.CompressionLevel]::Optimal,$false)
    Write-Host "[PASS] Created guarded PCC package: $out" -ForegroundColor Green
    Write-Host '[NEXT] Drop this .patch unextracted into repository root, approve in PCC, run Full Gate and manually test hull rendering.'
} finally {
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
}
