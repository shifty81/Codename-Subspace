# Visual and regression acceptance

1. Confirm the PCC still shows the expected baseline `cf5107e` and no competing root-drop patches. Approve only the generated R2 `.patch`.
2. Launch standalone Shipyard with a **new empty** document. Go Interior, then Build. The mode must automatically return to EXTERIOR. Drag a hull from Asset Browser: the ghost must render *while dragging*, before placing. Stage and PLACE; confirm hull geometry appears and Outliner has exactly one real module. Select it and use Frame Selected.
3. Cycle through workspaces with the existing keyboard shortcut. Interior → Build/Test/SYSTEMS must not leave EXTERIOR hidden. Explicit Cutaway and X-Ray modes must survive workspace changes.
4. In Build, manually cycle to INTERIOR-only and start a drag. It should return to EXTERIOR immediately. Use Add Module instead of drag and confirm appearance. Undo/redo, mirrored placement, normal gameplay ship rendering and cockpit input should not regress.
5. If the mode shows EXTERIOR but geometry is missing, inspect PCC/debug logs for `SHIPYARD_RUNTIME_NOT_READY`, `Could not load certified Shipyard module`, and missing `shipModules` entry for the Outliner module ID. This patch does not invent placeholder hull meshes or modify the certified-asset loader.
6. Run PCC Full Quality Gate. Visually check 1280×768 and 1920×1080. Commit + push certified GREEN only after actual hull visibility has been confirmed.
